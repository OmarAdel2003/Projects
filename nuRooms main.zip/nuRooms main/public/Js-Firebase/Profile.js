import {initializeApp,} from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
  import {
    getDatabase,
    ref,
    set,
    onValue,
    child,
    get,
    update,
    remove,
    push,
    serverTimestamp,
  } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-database.js";
  import {
    getAuth,
    OAuthProvider,
    signInWithPopup,
    onAuthStateChanged,
    signOut,
  } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";
  
import data from '../json/Data.json' assert {type : 'json'}
  // Your web app's Firebase configuration
  const firebaseConfig = {
    apiKey: "AIzaSyDe-WCbYKkHbGbbbMkQP_beuh5D2OONJy0",
    authDomain: "nurooms-c016d.firebaseapp.com",
    projectId: "nurooms-c016d",
    storageBucket: "nurooms-c016d.appspot.com",
    messagingSenderId: "268246812777",
    appId: "1:268246812777:web:257bb460b734ca1a453af8",
  };
  
  // Initialize Firebase
  const app = initializeApp(firebaseConfig);
  const db = getDatabase(app);
  const dbRef = ref(db);  

  const auth = getAuth();









  function Signout() {
    signOut(auth)
      .then(() => {
        window.location.href = "./Login.html";
      })
      .catch((error) => {
        // An error happened.
      });
  }
  
  module.Signout = Signout;


  onAuthStateChanged(auth, (user) => {
    if (user) {
        if (user.emailVerified) {

          const dbRef = ref(db);  

          let userName 
          let userEmail
          let isThereRoomBooked
          const sessions = document.getElementById('sessions')
            const  UserName = document.getElementById('UserName')
          // ================= Get User Data =============== //

          get(child(dbRef, "userData/" + user.uid)).then((snapshotUser) => {
            if (snapshotUser.exists()) {  
                UserName.innerHTML = snapshotUser.val().userName;
                userName= snapshotUser.val().userName;
              userEmail =user.email;
              isThereRoomBooked = snapshotUser.val().isThereRoomBooked
            }
      
          });

          const requestSessionForm = document.getElementById('requestSession')

          requestSessionForm.addEventListener('submit',(e)=>{
            e.preventDefault()
            console.log(requestSessionForm)
            sessionName = requestSessionForm['sessionName'].vlaue
  
            courseID = requestSessionForm['courseID'].vlaue
            sessionDescription = requestSessionForm['sessionDescription'].vlaue
            dateOfSession =requestSessionForm['dateOfSession'].vlaue
            sessionLink = requestSessionForm['sessionLink'].vlaue
            push(ref(db, "SessionsData/" ), {
              sessionName ,
              courseID,
              sessionDescription,
              dateOfSession,
              sessionLink ,
              MadeBy : userName,
              serverTimestamp :serverTimestamp()
              }).then((e) => {{
                update(ref(db, "userData/" + user.uid +'/SessionsAdded/'+e.key), {
                  
                  }).then(() => {{
                    sessions.innerHTML +=   
                    `
                 <div class="card h-100 w-75 mx-auto sessions" id='${e.key}'>
                    <div class="card-header pb-0 p-3">
                      <div class="row align-items-center text-center ">
                        <div class="g">
                          <button id="U${e.key}" onclick='module.UpdateSession(this.id)'><i class="fa-solid fa-pen"></i></button> 
                          <button id="D${e.key}" onclick='module.DeleteSession(this.id)'> <i class="fa-solid fa-trash  ms-5"></i></button> 
                       
                        </div>
                        
                        <h5>${sessionName}</h5>
                        <h6>${courseID}</h6>
              
                  
                        </div>
                    </div>
                    <div class="card-body p-3">
                      <ul class="list-group">
                        <label for="i">Session Description : </label><p ${sessionDescription}</p>
                        <label for="i">Session Date : </label><h5 >${dateOfSession}</h5>
                        <label for="i">Session Location : </label><h5 ><a href="${sessionLink}">Teams Metting Click here</a></h5>
                        <label for="i">Session Location : </label><h5 >${MadeBy}</h5>
                        
                      </ul>
        
                    </div>

                    <div class="card-footer float-start">
                      <label for="i">Status Of Session : </label><h5 id="i" class="text-success">Active</h5>

                    </div>
                  </div>
   
            
                    `
                  }})
              }})
          })

          function DeleteSession(ID) {
              let newID = ID.slice(1)
              remove(ref(db, "userData/" + user.uid +'/SessionsAdded/'+newID), {
                  
              }).then(() => {{
                remove(ref(db,"SessionsData/"+newID), {
                  
                }).then(() => {{
                  document.getElementById(`${newID}`).remove
                }})
              }})
          }
          module.DeleteSession=DeleteSession

       

        }else{
          window.location.href="./Login.html"

        }
    
    }else {
      window.location.href="./Login.html"

     }
  });