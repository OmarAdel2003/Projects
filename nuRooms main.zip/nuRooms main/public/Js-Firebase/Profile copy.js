import {initializeApp,} from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
  import {
    getDatabase,
    ref,
    set,
    onValue,
    child,
    get,
    update,
    remove,
    push,
    serverTimestamp,
  } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-database.js";
  import {
    getAuth,
    OAuthProvider,
    signInWithPopup,
    onAuthStateChanged,
    signOut,
  } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";
  
import data from '../json/Data.json' assert {type : 'json'}
  // Your web app's Firebase configuration
  const firebaseConfig = {
    apiKey: "AIzaSyDe-WCbYKkHbGbbbMkQP_beuh5D2OONJy0",
    authDomain: "nurooms-c016d.firebaseapp.com",
    projectId: "nurooms-c016d",
    storageBucket: "nurooms-c016d.appspot.com",
    messagingSenderId: "268246812777",
    appId: "1:268246812777:web:257bb460b734ca1a453af8",
  };
  
  // Initialize Firebase
  const app = initializeApp(firebaseConfig);
  const db = getDatabase(app);
  const dbRef = ref(db);  

  const auth = getAuth();





  function Signout() {
    signOut(auth)
      .then(() => {
        window.location.href = "./Login.html";
      })
      .catch((error) => {
        // An error happened.
      });
  }
  
  module.Signout = Signout;


  onAuthStateChanged(auth, (user) => {
    if (user) {
        if (user.emailVerified) {

          const dbRef = ref(db);  

          let userName 
          let userEmail
          let isThereRoomBooked

            const  UserName = document.getElementById('UserName')
          // ================= Get User Data =============== //

          get(child(dbRef, "userData/" + user.uid)).then((snapshotUser) => {
            if (snapshotUser.exists()) {  
                UserName.innerHTML = snapshotUser.val().userName;
              userEmail =user.email;
              isThereRoomBooked = snapshotUser.val().isThereRoomBooked
            }
      
          });

       

        }else{
          window.location.href="./Login.html"

        }
    
    }else {
      window.location.href="./Login.html"

     }
  });